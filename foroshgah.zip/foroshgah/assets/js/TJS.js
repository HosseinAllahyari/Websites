theTarget = document.querySelector('.img-showcase');
theTarget2 = document.querySelector('.items')

let sp = {
    spx: 0,
    spy: 0
}

let mp = {
    mpx: 0,
    mpy: 0
}
let ep = {
    epx: '0',
    epy: '0'
}

let arrm = [];
let i = { i: 0 }

let temp = [0, 0, 0, 0]


theTarget.addEventListener('touchstart', e => {
    temp[0] =Number(checking(theTarget.style['transform']));
    theTarget.style.transition =  'none';
    [...e.changedTouches].forEach(touch => {
        sp.spx = touch.pageX;
        sp.spy = touch.pageY;

    });

});

theTarget.addEventListener('touchmove', e => {
    [...e.changedTouches].forEach(touch => {
        mp.mpx = touch.pageX;
        mp.mpy = touch.pageY;
        arrm[i.i] = mp.mpx
        console.log(arrm)
        if ( i.i != 0 && i.i-1 != 0) {
            console.log( temp[1] = arrm[i.i] - arrm[i.i - 1])
            temp[2] = arrm[i.i]
            document.querySelector('.img-showcase').style.transform = `translateX(${temp[0] = temp[0] + (arrm[i.i] - arrm[i.i - 1]) }px)`;
            console.log( temp[1] )
            
        }
        i.i = i.i + 1


    });




});

theTarget.addEventListener('touchend', e => {
    theTarget.style.transition =  'all 0.4s ease';
    [...e.changedTouches].forEach(touch => {
        
        ep.epx = touch.pageX;
        temp[3] = ep.epx;
        console.log(ep.epx);
    });
    document.querySelector('.img-showcase').style.transform = `translateX(${temp[0] = temp[0]  + temp[1] * 10 + (temp[3] - arrm[i.i - 1]) * 4 }px)`;

    arrm = [];
    i.i = 0;
    temp = [0, 0, 0, 0]
    ep.px = 0;
    mp.mpx = 0;
    sp.spx = 0;
    //  alert(theTarget.style['transform']);
});




theTarget2.addEventListener('touchstart', e => {
    temp[0] =Number(checking(theTarget2.style['transform']));
    theTarget2.style.transition =  'none';
    [...e.changedTouches].forEach(touch => {
        sp.spx = touch.pageX;
        sp.spy = touch.pageY;

    });

});

theTarget2.addEventListener('touchmove', e => {
    [...e.changedTouches].forEach(touch => {
        mp.mpx = touch.pageX;
        mp.mpy = touch.pageY;
        arrm[i.i] = mp.mpx
        console.log(arrm)
        if ( i.i != 0 && i.i-1 != 0) {
            console.log( temp[1] = arrm[i.i] - arrm[i.i - 1])
            temp[2] = arrm[i.i]
            theTarget2.style.transform = `translateX(${temp[0] = temp[0] + (arrm[i.i] - arrm[i.i - 1]) }px)`;
            console.log( temp[1] )
            
        }
        i.i = i.i + 1


    });




});

theTarget2.addEventListener('touchend', e => {
    theTarget2.style.transition =  'all 0.5s ease';
    [...e.changedTouches].forEach(touch => {
        
        ep.epx = touch.pageX;
        temp[3] = ep.epx;
        console.log(ep.epx);
    });
    theTarget2.style.transform = `translateX(${temp[0] = temp[0]  + temp[1] * 10 + (temp[3] - arrm[i.i - 1]) * 4 }px)`;

    arrm = [];
    i.i = 0;
    //  alert(theTarget.style['transform']);
});


function checking(x1) {
    // Input string
    let str = x1;
    let c = "0123456789.-";
    function check(x) {
        return c.includes(x) ? true : false;
    }
    let matches = [...str].reduce(
        (x, y) => (check(y) ? x + y : x),"");

    // Display output if number extracted
    return matches;
}
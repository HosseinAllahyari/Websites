
    const cardWidth = document.querySelector('.card').clientWidth;
    const chevR = document.querySelector('.fa-chevron-right');
    const chevL = document.querySelector('.fa-chevron-left');
    const items = document.querySelector('.items');
    const tempt = [0];


    if ( window.outerWidth <= 600 ) {

        chevL.addEventListener('click', () => {
            tempt[0] = Number(checking(items.style['transform']));
            items.style['transition'] = `all 0.7s ease`;
            items.style['transform'] = `translateX(${tempt[0]  = tempt[0]  + 125}px)`;
            // alert(Number(checking(items.style['transform'])));
        });
        chevR.addEventListener('click', () => {
            tempt[0] = Number(checking(items.style['transform']));
            items.style['transition'] = `all 0.7s ease`;
            items.style['transform'] = `translateX(${tempt[0]  = tempt[0]  - 125}px)`;
        });
    }
    else {

        
        chevL.addEventListener('click', () => {
            tempt[0] = Number(checking(items.style['transform']));
            items.style['transition'] = `all 0.7s ease`;
            items.style['transform'] = `translateX(${tempt[0]  = tempt[0]  + 250}px)`;
        });
        chevR.addEventListener('click', () => {
            tempt[0] = Number(checking(items.style['transform']));
            items.style['transition'] = `all 0.7s ease`;
            items.style['transform'] = `translateX(${tempt[0]  = tempt[0]  - 250}px)`;
        });

    }




function checking(x1) {
    // Input string
    let str = x1;
    let c = "0123456789.-";
    function check(x) {
        return c.includes(x) ? true : false;
    }
    let matches = [...str].reduce(
        (x, y) => (check(y) ? x + y : x),"");

    // Display output if number extracted
    return matches;
}
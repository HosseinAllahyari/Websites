$(document).ready(function () {
    $('.fa-bars').click(function () {
        $(this).toggleClass('fa-times');
        $('.nav-list').toggleClass('nav-list-t');
    });
    $(".items .card").click(function() {
        location.assign("/templates/stuff.html");
    });
});